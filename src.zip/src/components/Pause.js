import * as React from "react";

import Box from "@mui/material/Box";
import MuiInput from "@mui/material/Input";
import FormControl from "@mui/material/FormControl";
import Button from "@mui/material/Button";
import Col from "react-bootstrap/Col";
import Row from "react-bootstrap/Row";

const Input = styled(MuiInput)`
  width: 100%;
`;
export default function Pause() {
  return (
    <Box>
      <FormControl fullWidth>
        <Row>
          <Col xs={9} md={9}>
            <Input
              size="small"
              inputProps={{
                type: "number",
              }}
            />
          </Col>
          <Col xs={3} md={3}>
            <Button variant="outlined">
              <i class="fa fa-check" aria-hidden="true"></i>
            </Button>
          </Col>
        </Row>
      </FormControl>
    </Box>
  );
}
