import * as React from "react";
import Box from "@mui/material/Box";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import Select from "@mui/material/Select";
import InputLabel from '@mui/material/InputLabel';

export default function ReadingRules() {
  const [rule, setRule] = React.useState("");

  const handleChange = (event) => {
    setRule(event.target.value);
    console.log(event.target.value);
  };

  return (
    <Box sx={{ minWidth: 120 }}>
      <FormControl fullWidth>
      <InputLabel id="demo-simple-select-label">Default</InputLabel>
        <Select
          labelId="demo-simple-select-label"
          id="demo-simple-select"
          value={rule}
          onChange={handleChange}
          displayEmpty
        >
          <MenuItem value={"default"}>Default</MenuItem>
          <MenuItem value={"X-Week"}>X-Week</MenuItem>
          <MenuItem value={"Week"}>Week</MenuItem>
          <MenuItem value={"Medium"}>Medium</MenuItem>
          <MenuItem value={"Strong"}>Strong</MenuItem>
          <MenuItem value={"X-Strong"}>X-Strong</MenuItem>
        </Select>
      </FormControl>
    </Box>
  );
}
